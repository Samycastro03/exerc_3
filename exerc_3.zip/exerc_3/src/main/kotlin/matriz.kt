fun main(args: Array<String>){
    val matriz = Array(3) {arrayOfNulls<Int>(3)}

    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1
    matriz[0][0] = 1

    for((linha, linhaArray) in matriz.withIndex()){

    }
}